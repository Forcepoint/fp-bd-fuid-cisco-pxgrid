#!/bin/bash

if ! [ -x "$(command -v go)" ]; then
    if ! [ -x "$(command -v wget)" ]; then
        echo "********** installing wget **********"
        sudo yum install wget -y
    fi
    echo "******** Installing Golang v1.15.1 *********"
    wget https://dl.google.com/go/go1.15.1.linux-amd64.tar.gz
    sudo tar -zxvf go1.15.1.linux-amd64.tar.gz -C /usr/local
    echo "export GOROOT=/usr/local/go" | sudo tee -a /etc/profile
    echo "export PATH=$PATH:/usr/local/go/bin" | sudo tee -a /etc/profile
    source /etc/profile
fi
chmod +x fuid-ise
mkdir /var/fuid-ise
mkdir /var/fuid-ise/fuid-ise-logs
mkdir /var/fuid-ise/latest-timestamp
mv fuid-ise.service /etc/systemd/system/
mv fuid-ise /var/fuid-ise/
mv fuid-ise.yml /var/fuid-ise/
sudo systemctl enable fuid-ise.service